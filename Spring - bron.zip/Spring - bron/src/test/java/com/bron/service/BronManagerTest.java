package com.bron.service;

import static org.hamcrest.CoreMatchers.either;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;


import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.bron.domain.Bron;
import com.bron.domain.Person;
import com.bron.domain.Fabryka;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/beans.xml" })
@TransactionConfiguration(transactionManager = "txManager", defaultRollback = false)
@Transactional
public class BronManagerTest {

	@Autowired
	 BronManager bronManager;
	
  	private final static String NAZWA_1 = "Ak-47";
	private final static int KALIBER_1 = 7;
	private final static double CENA_1 = 1999.99;
	private final static String TYP_1 = "Palna";	
	private final static double CENA_2 = 2999.99;
	private static final String NAZWAF_1 = "Trump Inc.";
	private static final String NAZWAF_2 = "Wodnik";
	private static final String IMIE_1 = "Tadeusz";
	private static final String NAZWISKO_1 = "Kowalski";
	private static final String EMAIL_1 = "ttt.kowalski@gmail.com";
	private static final String NAZWISKO_2 = "Knutt";
	private static final String IMIE_2 = "Kamil";

	
	Fabryka fabryka1 = new Fabryka(NAZWAF_1);	
	Person person1 = new Person(IMIE_1, NAZWISKO_1, EMAIL_1);
	Bron bron1 = new Bron(NAZWA_1, KALIBER_1, CENA_1, TYP_1, new Person(), new Fabryka());
	
  @Test
  public void checkAddBron() {
	  	bronManager.removeAllBronie();
		bronManager.addBron(bron1);
		
		List<Bron> bronie = bronManager.getAllBronie();
		Bron bronRetrieved = bronie.get(0);
		
		assertEquals(NAZWA_1, bronRetrieved.getNazwa());
		assertEquals(KALIBER_1, bronRetrieved.getKaliber());
		assertEquals(CENA_1, bronRetrieved.getCena(), 5);
		assertEquals(TYP_1, bronRetrieved.getTyp());
	    bronManager.removeBron(bronRetrieved);
  }

  @Test
  public void checkGetAllBronie() {
    int bronieCounter = bronManager.getAllBronie().size();
    assertThat(bronieCounter, either(is(0)).or(is(1)));
  }
  
  @Test
  public void checkUpdateBron() {
	  	bronManager.removeAllBronie();
	  	Bron brontt1 = bron1;
		bronManager.addBron(brontt1);
		brontt1.setCena(CENA_2);
		bronManager.updateBron(brontt1);
		
		List<Bron> bronie = bronManager.getAllBronie();
		Bron bronRetrieved = bronie.get(0);
		
		assertEquals(NAZWA_1, bronRetrieved.getNazwa());
		assertEquals(KALIBER_1, bronRetrieved.getKaliber());
		assertEquals(CENA_2, bronRetrieved.getCena(), 5);
		assertEquals(TYP_1, bronRetrieved.getTyp());
	    bronManager.removeBron(bronRetrieved);
  }

  @Test
  public void checkRemoveBron() {
	  
    bronManager.addBron(bron1);
    int Broncounter = bronManager.getAllBronie().size();
    Bron bronRetrieved = bronManager.getAllBronie().get(Broncounter - 1);
    bronManager.removeBron(bronRetrieved);

    int BronCounter2 = bronManager.getAllBronie().size();
    assertEquals(Broncounter - 1, BronCounter2);
  }

  @Test
  public void checkSearchBronByName() {
	bronManager.addBron(bron1);

    String nazwa = bron1.getNazwa();
    Bron bronRetrieved = bronManager.findBronByNazwa(nazwa);
    assertEquals(bronRetrieved, bron1);

    bronManager.removeBron(bronRetrieved);
  }

  //fabryki
  @Test
  public void checkAddFabryka() {
	  	bronManager.removeAllFabryki();
		bronManager.addFabryka(fabryka1);
		
		List<Fabryka> fabryki = bronManager.getAllFabryki();
		Fabryka fabrykaRetrieved = fabryki.get(0);
		
		assertEquals(NAZWAF_1, fabrykaRetrieved.getNazwa());
	    bronManager.removeFabryka(fabrykaRetrieved);
  }

  @Test
  public void checkGetAllFabryki() {
    int fabrykiCounter = bronManager.getAllFabryki().size();
    assertThat(fabrykiCounter, either(is(0)).or(is(1)));
  }

  @Test
  public void checkUpdateFabryka() {
	  	bronManager.removeAllFabryki();
	  	Fabryka fabrykatt = new Fabryka(NAZWAF_2);
		bronManager.addFabryka(fabrykatt);
		fabrykatt.setNazwa(NAZWAF_1);

		bronManager.updateFabryka(fabrykatt);
		
		List<Fabryka> fabryki = bronManager.getAllFabryki();
		Fabryka fabrykaRetrieved = fabryki.get(0);
		
		assertEquals(NAZWAF_1, fabrykaRetrieved.getNazwa());
	    bronManager.removeFabryka(fabrykaRetrieved);
  }

  @Test
  public void checkRemoveFabryka() {
	    bronManager.addFabryka(fabryka1);
	    int Fabrykacounter = bronManager.getAllFabryki().size();
	    Fabryka fabrykaRetrieved = bronManager.getAllFabryki().get(Fabrykacounter - 1);
	    bronManager.removeFabryka(fabrykaRetrieved);

	    int Fabrykacounter2 = bronManager.getAllFabryki().size();
	    assertEquals(Fabrykacounter - 1, Fabrykacounter2);
  }

  @Test
  public void checkSearchFabryka() {
		Fabryka fabrykatt = new Fabryka(NAZWAF_1);
	    bronManager.addFabryka(fabrykatt);

	    String nazwa = fabrykatt.getNazwa();
	    Fabryka fabrykaRetrieved = bronManager.findFabrykaByNazwa(nazwa);
	    assertEquals(fabrykaRetrieved, fabrykatt);

	    bronManager.removeFabryka(fabrykaRetrieved);
  }

  //persons
  @Test
  public void checkAddPerson() {
	  	bronManager.removeAllPersons();
		bronManager.addPerson(person1);
		
		List<Person> persons = bronManager.getAllPersons();
		Person personRetrieved = persons.get(0);
		
		assertEquals(IMIE_1, personRetrieved.getImie());
		assertEquals(NAZWISKO_1, personRetrieved.getNazwisko());
		assertEquals(EMAIL_1, personRetrieved.getEmail());
	    bronManager.removePerson(personRetrieved);
  }

  @Test
  public void checkGetAllPersons() {
    int personsCounter = bronManager.getAllPersons().size();
    assertThat(personsCounter, either(is(0)).or(is(1)));
  }

  @Test
  public void checkUpdatePerson() {
	  	bronManager.removeAllPersons();
	  	Person persontt = new Person(IMIE_2, NAZWISKO_1, EMAIL_1);
		bronManager.addPerson(persontt);
		persontt.setNazwisko(NAZWISKO_2);

		bronManager.updatePerson(persontt);
		
		List<Person> persons = bronManager.getAllPersons();
		Person personRetrieved = persons.get(0);
		
		assertEquals(IMIE_2, personRetrieved.getImie());
		assertEquals(NAZWISKO_2, personRetrieved.getNazwisko());
		assertEquals(EMAIL_1, personRetrieved.getEmail());
	    bronManager.removePerson(personRetrieved);
  }
  @Test
  public void checkRemovePerson() {
		bronManager.addPerson(person1);
	    int Personcounter = bronManager.getAllPersons().size();
	    Person personRetrieved = bronManager.getAllPersons().get(Personcounter - 1);
	    bronManager.removePerson(personRetrieved);

	    int Personcounter2 = bronManager.getAllPersons().size();
	    assertEquals(Personcounter - 1, Personcounter2);
  }

  @Test
  public void checkSearchPerson() {
	  	bronManager.removeAllPersons();
		bronManager.addPerson(person1);

	    String email = person1.getEmail();
	    Person personRetrieved = bronManager.findPersonByEmail(email);
	    assertEquals(personRetrieved, person1);

	    bronManager.removePerson(personRetrieved);
	    
	    
  }

}
